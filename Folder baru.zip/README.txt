PAKET WEBSITE PROFIL PRIBADI AYU KURNIASARI

Isi:
- index.html: halaman profil pribadi (bukan website portofolio makeup)
- images/: foto asli yang sebelumnya telah diberikan
- robots.txt dan sitemap.xml: petunjuk dasar untuk mesin pencari

Unggah ISI folder ini ke repository GitHub yang khusus untuk profil pribadi.
Jangan unggah ke repository atau Worker ayu-makeup-artist.
Jangan hapus website lama sebelum website baru berhasil diperiksa.
